﻿#!/bin/bash
apt install krb5-kdc krb5-admin-server krb5-pkinit -y > /etc/krb5.conf
content_krb5=$(< /scripts/krb5-conf.txt)
echo "$content_krb5" > /etc/krb5.conf
apt install winbind -y
net ads join -U Administrator 
service winbind restart
apt install libnss-winbind -y
content_nss=$(< /scripts/nsswitch-conf.txt) 
echo "$content_nss" > /etc/nsswitch.conf
apt install samba -y > /etc/samba/smb.conf
mkdir -p /share/samba
chown 1000: /share/samba
content_smb=$(< /scripts/smb-conf.txt)
echo "$content_smb" > /etc/samba/smb.conf
echo "session optional pam_mkhomedir.so" >>  /etc/pam.d/samba
service winbind restart
systemctl restart nmbd
